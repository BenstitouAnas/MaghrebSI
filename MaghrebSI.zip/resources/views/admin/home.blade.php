@extends('layouts.admin')

@section('title',"Admin - Tableau de bord")

@section('js_css')

@endsection

@section('content')

@endsection

@section('script_footer')

@endsection
