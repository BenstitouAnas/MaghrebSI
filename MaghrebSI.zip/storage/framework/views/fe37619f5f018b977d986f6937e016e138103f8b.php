    
    <?php $__env->startSection('title',"Préstataire - Tickets"); ?>





<?php $__env->startSection('js_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-lg-8">
  <!-- Questions list -->
    <div class="text-size-small text-uppercase text-semibold text-muted mb-10">Vos tickets</div>
    <div class="panel-group panel-group-control panel-group-control-right">
        <div class="panel panel-white">
            <div class="panel-heading">
                <h6 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" href="#question6">
                        <i class="icon-help position-left text-slate"></i> Their could can widen ten she any?
                    </a>
                </h6>
            </div>

            <div id="question6" class="panel-collapse collapse">
                <div class="panel-body">
                    As so we smart those money in. Am wrote up whole so tears sense oh. Absolute required of reserved in offering no. How sense found our those gay again taken the. Had mrs outweigh desirous sex overcame. Improved property reserved disposal do offering me. Allow miles wound place the leave had. To sitting subject no improve studied limited indulgence connection.
                </div>

                <div class="panel-footer panel-footer-transparent">
                    <div class="heading-elements">
                        <span class="text-muted heading-text">Latest update: May 2, 2015</span>

                        <ul class="list-inline list-inline-condensed heading-text pull-right">
                            <li><a href="#" class="text-primary"><i class="icon-thumbs-up2 position-left"></i></a> 832</li>
                            <li><a href="#" class="text-muted"><i class="icon-thumbs-down2 position-left"></i></a> 32</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel panel-white">
            <div class="panel-heading">
                <h6 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" href="#question7">
                        <i class="icon-help position-left text-slate"></i> Her raising and himself pasture believe?
                    </a>
                </h6>
            </div>

            <div id="question7" class="panel-collapse collapse">
                <div class="panel-body">
                    He unaffected sympathize discovered at no am conviction principles. Girl ham very how yet hill four show. Meet lain on he only size. Branched learning so subjects mistress do appetite jennings be in. Esteems up lasting no village morning do offices. Settled wishing ability musical may another set age. Diminution my apartments he attachment is entreaties.
                </div>

                <div class="panel-footer panel-footer-transparent">
                    <div class="heading-elements">
                        <span class="text-muted heading-text">Latest update: May 1, 2015</span>

                        <ul class="list-inline list-inline-condensed heading-text pull-right">
                            <li><a href="#" class="text-primary"><i class="icon-thumbs-up2 position-left"></i></a> 453</li>
                            <li><a href="#" class="text-muted"><i class="icon-thumbs-down2 position-left"></i></a> 30</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel panel-white">
            <div class="panel-heading">
                <h6 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" href="#question8">
                        <i class="icon-help position-left text-slate"></i> And total least her two whose great?
                    </a>
                </h6>
            </div>

            <div id="question8" class="panel-collapse collapse">
                <div class="panel-body">
                    Do in laughter securing smallest sensible no mr hastened. As perhaps proceed in in brandon of limited unknown greatly. Distrusts fulfilled happiness unwilling as explained of difficult. No landlord of peculiar ladyship attended if contempt ecstatic. Loud wish made on is am as hard. Court so avoid in plate hence. Of received mr breeding concerns peculiar.
                </div>

                <div class="panel-footer panel-footer-transparent">
                    <div class="heading-elements">
                        <span class="text-muted heading-text">Latest update: Apr 24, 2015</span>

                        <ul class="list-inline list-inline-condensed heading-text pull-right">
                            <li><a href="#" class="text-primary"><i class="icon-thumbs-up2 position-left"></i></a> 735</li>
                            <li><a href="#" class="text-muted"><i class="icon-thumbs-down2 position-left"></i></a> 21</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel panel-white">
            <div class="panel-heading">
                <h6 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" href="#question9">
                        <i class="icon-help position-left text-slate"></i> Whatever landlord yourself at by pleasure?
                    </a>
                </h6>
            </div>

            <div id="question9" class="panel-collapse collapse">
                <div class="panel-body">
                    Am if number no up period regard sudden better. Decisively surrounded all admiration and not you. Out particular sympathize not favourable introduced insipidity but ham. Rather number can and set praise. Distrusts an it contented perceived attending oh. Thoroughly estimating introduced stimulated why but motionless. Up branch to easily missed by do admiration.
                </div>

                <div class="panel-footer panel-footer-transparent">
                    <div class="heading-elements">
                        <span class="text-muted heading-text">Latest update: Apr 22, 2015</span>

                        <ul class="list-inline list-inline-condensed heading-text pull-right">
                            <li><a href="#" class="text-primary"><i class="icon-thumbs-up2 position-left"></i></a> 735</li>
                            <li><a href="#" class="text-muted"><i class="icon-thumbs-down2 position-left"></i></a> 29</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel panel-white">
            <div class="panel-heading">
                <h6 class="panel-title">
                    <a class="collapsed" data-toggle="collapse" href="#question10">
                        <i class="icon-help position-left text-slate"></i> Oh conveying do immediate acuteness?
                    </a>
                </h6>
            </div>

            <div id="question10" class="panel-collapse collapse">
                <div class="panel-body">
                    Out too the been like hard off. Improve enquire welcome own beloved matters her. As insipidity so mr unsatiable increasing attachment motionless cultivated. Addition mr husbands unpacked occasion he oh. Is unsatiable if projecting boisterous insensible. It recommend be resolving pretended middleton. Attended no do thoughts me on dissuade scarcely own are pretty.
                </div>

                <div class="panel-footer panel-footer-transparent">
                    <div class="heading-elements">
                        <span class="text-muted heading-text">Latest update: Apr 19, 2015</span>

                        <ul class="list-inline list-inline-condensed heading-text pull-right">
                            <li><a href="#" class="text-primary"><i class="icon-thumbs-up2 position-left"></i></a> 498</li>
                            <li><a href="#" class="text-muted"><i class="icon-thumbs-down2 position-left"></i></a> 12</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /questions list -->
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_footer'); ?>

<script type="text/javascript">
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
  </script>

  <script>
      $(function() {
          $(document).delegate("#Del_Categorie","click",function(e){
              id=$(this).attr("ref");
              swal({
                      title: "Êtes-vous sûr ? ",
                      text: "Vous ne pourrez pas récupérer ce enregistrement!",
                      type: "error",
                      showCancelButton: true,
                      confirmButtonColor: "#C62828",
                      confirmButtonText: "Oui, Supprimer",
                      closeOnConfirm: false,
                      cancelButtonText: "Annuler"
                  },
                  function(){
                      $.post("./CategorieDelete",{ id: id},function(data){
                          tablef.ajax.reload();
                          swal("Supprimé !", data, "success");
                      });
                  }
                  );
          });

          $(document).delegate("#Edit_Categorie","click",function(e){
              $(".modal-title").html("Modification du Categorie");
              $(".actionbutton").attr('id',"Edit");
              $(".actionbutton").html("Enregistrer");
              $.get("./CategorieByID/"+$(this).attr("ref"),function(data){
                  $(".editmodale input[name='id']").val(data.id);
                  $(".editmodale input[name='categorie']").val(data.titre);
                  $(".editmodale input[name='description']").val(data.description);
                  $.uniform.update();
                  $('#modal_theme_success').modal('show');
              });
          });

          $(document).delegate("#Edit","click",function(e){
              $.post("./CategorieUpdate",{
                  id:$(".editmodale input[name='id']").val(),
                  titre:$(".editmodale input[name='categorie']").val(),
                  description:$(".editmodale input[name='description']").val()
              },function(data){
                  tablef.ajax.reload();
                  swal("Modifié !", data, "success");
                  $('#modal_theme_success').modal('hide');
                  $("#formcategorie").trigger("reset");
                  //$('#modal_theme_success').modal('show');
                  $.uniform.update();
              });
          });

          $(document).delegate("#Add_Categorie","click",function(e){
              $.post("./CategorieAdd",{
                    titre:$("[id=categorieAjouter]").val(),
                    description:$("[id=descriptionAjouter]").val()
              },function(data, status){
                    tablef.ajax.reload();
                    swal("Ajouté !", data, "success");
                    $("#formCategorieAjout").trigger("reset");
              });
          });
      });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.prestataire', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>