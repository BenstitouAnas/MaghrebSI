@extends('layouts.client')

@section('title',"Client - Tableau de bord")

@section('js_css')

@endsection

@section('content')

@endsection

@section('script_footer')

@endsection
