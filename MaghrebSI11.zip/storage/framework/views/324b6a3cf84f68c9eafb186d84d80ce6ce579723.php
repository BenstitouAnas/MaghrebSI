<?php $__env->startSection('title',"Préstataire - Produits"); ?>

<?php $__env->startSection('js_css'); ?>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/notifications/pnotify.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/pages/form_input_groups.js')); ?>"></script>

  <script type="text/javascript" src="<?php echo e(asset('assets/js/plugins/forms/inputs/touchspin.min.js')); ?>"></script>

  <script type="text/javascript"> idDealData = <?php echo e($produit->id); ?></script>

  <script type="text/javascript" src="<?php echo e(asset('js/prestataire/datatables_deals.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
    <div class="alert alert-success alert-styled-left alert-arrow-left alert-bordered">
        <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
        <span class="text-semibold">Ajout avec secces ! </span> votre produit est bien ajouté à la liste des produits, penser à ajouter des deals.
    </div>
<?php endif; ?>
<div class="panel panel-flat panel-collapsed">
    <div class="panel-heading">
        <h5 class="panel-title">Detailles Deal</h5>
        <div class="heading-elements">
            <ul class="icons-list">
                <li><a data-action="collapse"></a></li>
            </ul>
        </div>
    </div>

    <div class="panel-body">
     
        <div class="form-horizontal editmodale" id="formAjoutProduit">

        <input type="hidden" class="form-control" name="id" value="<?php echo e($produit->id); ?>">

            <div class="form-group">
                <label class="control-label col-lg-2">Nom du Produit</label>
                <div class="col-lg-10">
                    <input type="text" class="form-control" name="libelle" value="<?php echo e($produit->libelle); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">Catégorie</label>
                <div class="col-lg-10">
                    <select name="categorie" class="form-control" id="selectCategorie">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($categorie->id == $produit->categorie_id): ?>
                                <option value="<?php echo e($categorie->id); ?>" selected="selected"><?php echo e($categorie->titre); ?></option>
                            <?php endif; ?>
                            <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->titre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">Documentation Technique</label>
                <div class="col-lg-10">
                    <input type="text" class="form-control" name="documentationTechnique" value="<?php echo e($produit->documentationTechnique); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">Image Produit</label>
                <div class="col-lg-10">
                    <div class="uploader">
                        <input id="imageProduit" type="file" class="file-styled-primary" name="image" value="<?php echo e($produit->image); ?>">
                        <span class="filename" style="user-select: none;" id="imagep"><?php echo e($produit->image); ?></span>
                        <span class="action btn bg-blue" style="user-select: none;">Choisir Fichier</span>
                    </div>
                </div>
            </div>

            <div class="text-right">
                <button type="reset" class="btn btn-default" id="btnAnnuler">Annuler </button>
                <button type="submit" class="btn btn-primary actionbutton" id="modifierArticle">Modifier <i class="icon-arrow-right14 position-right"></i></button>
            </div>

        </div>
    </div>
</div>
<!-- ****************************************************************************************************************** -->

  <!-- Basic datatable -->
  <div class="panel panel-flat">
      <div class="panel-heading">
          <h6 class="panel-title">Liste des Deals</h6>
          <div class="heading-elements">
      			<ul class="icons-list">
                    <li><button type="button" class="btn btn-primary addbutton" id="Add_Deal"><i class="glyphicon glyphicon-plus"></i>  Ajouter Deal</button></li>
      				<li><a data-action="collapse"></a></li>
      			</ul>
      		</div>
      </div>

      <hr class="no-margin">
      <table class="table datatable-basic table-bordered" id="allclients">
          <thead>
          <tr>
              <th>Titre</th>
              <th>Prix</th>
              <th>Nombre Places</th>
              <th>Date Limite</th>
              <th>Action</th>
          </tr>
          </thead>
          <tbody>

          </tbody>
      </table>
  </div>
  <!-- /basic datatable -->

  <!-- Vertical form modal -->
    <div id="modalInfoPrestataire" class="modal fade editmodale2">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h5 class="modal-title">Ajouter Deal</h5>
                </div>

                <form id="formprestataire" action="get" onsubmit="return false;">
                    <div class="modal-body">
                    <form id="formprestataire" action="get" onsubmit="return false;">
                        <div class="form-group">
                            <label>Titre</label>
                            <input type="text" placeholder="Nom" class="form-control" name="titre">
                            <input type="hidden" class="form-control" name="idDeal">
                        </div>

                        <div class="form-group">
                            <label>Prix</label>
                            <input type="text" value="0" class="touchspin-prefix" name="prix" id="prix">
                        </div>

                        <div class="form-group">
                            <label>Nombre du Places</label>
                            <input type="text" value="1" class="touchspin-no-mousewheel" name="nomrbePlaces" id="nomrbePlaces">
                        </div>

                        <div class="form-group">
                            <label>Date Limite</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                                <input type="text" class="form-control daterange-single" value="2017-06-17" name="dateLimite">
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-link" data-dismiss="modal">Retour</button>
                        <button type="button" class="btn btn-primary" id="addDeal">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /vertical form modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_footer'); ?>

<script type="text/javascript">
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
  </script>

  <script>
      $(function() {

          $(document).delegate("#imageProduit","change",function(e){
                $("#imagep").text(e.target.files[0].name);
                //$(".editmodale input[name='image']").val(e.target.files[0].name);
            });

          $('#formAjoutProduit').find('input, select').attr('disabled',true);
          $('#btnAnnuler').hide();

          $(document).delegate("#Del_Deal","click",function(e){
              id=$(this).attr("ref");
              swal({
                      title: "Êtes-vous sûr ? ",
                      text: "Vous ne pourrez pas récupérer ce enregistrement!",
                      type: "error",
                      showCancelButton: true,
                      confirmButtonColor: "#C62828",
                      confirmButtonText: "Oui, Supprimer",
                      closeOnConfirm: false,
                      cancelButtonText: "Annuler"
                  },
                  function(){
                      $.post("../DealDelete",{ id: id},function(data){
                          tablef.ajax.reload();
                          swal("Supprimé !", data, "success");
                      });
                  }
                  );
          });

          $(document).delegate("#Edit_Deal","click",function(e){
              $(".modal-title").html("Modification du Deal");
              $("#addDeal").attr('id',"Edit");
              $("#addDeal").html("Enregistrer");
              $.get("../DealByID/"+$(this).attr("ref"),function(data){
                  $(".editmodale2 input[name='idDeal']").val(data.id);
                  $(".editmodale2 input[name='titre']").val(data.titre);
                  $(".editmodale2 input[name='prix']").val(data.prix);
                  $(".editmodale2 input[name='nomrbePlaces']").val(data.nombrePlaces);
                  $(".editmodale2 input[name='dateLimite']").val(data.dateLimite);
                  $.uniform.update();
                  $('#modalInfoPrestataire').modal('show');
              });
          });

          $(document).delegate("#Edit","click",function(e){
              $.post("../DealUpdate",{
                  id:$(".editmodale2 input[name='idDeal']").val(),
                  titre:$(".editmodale2 input[name='titre']").val(),
                  prix:$(".editmodale2 input[name='prix']").val(),
                  nombrePlaces:$(".editmodale2 input[name='nomrbePlaces']").val(),
                  dateLimite:$(".editmodale2 input[name='dateLimite']").val()
              },function(data){
                  tablef.ajax.reload();
                  swal("Modifié !", data, "success");
                  $('#modalInfoPrestataire').modal('hide');
                  $("#formcategorie").trigger("reset");
                  //$('#modal_theme_success').modal('show');
                  $.uniform.update();
              });
          });

          $(document).delegate("#modifierArticle","click",function(e){
                $('#formAjoutProduit').find('input, select').attr('disabled',false);
                $('#btnAnnuler').show();
                $("#modifierArticle").html("Enregistrer");
                $("#modifierArticle").attr('id',"enregisterModification");
                
            });
            
        $(document).delegate("#Add_Deal","click",function(e){
                $("#formprestataire").trigger("reset");
                $.uniform.update();
                $(".modal-title").html("Ajouter Deal");
                $('#modalInfoPrestataire').modal('show');
          });

          $(document).delegate("#addDeal","click",function(e){
              $.post("../DealAdd",{
                  produit_id:$(".editmodale input[name='id']").val(),
                  titre:$(".editmodale2 input[name='titre']").val(),
                  prix:$(".editmodale2 input[name='prix']").val(),
                  dateLimite:$(".editmodale2 input[name='dateLimite']").val(),
                  nombrePlaces:$(".editmodale2 input[name='nomrbePlaces']").val()
              },function(data){
                tablef.ajax.reload();
                $("#formprestataire").trigger("reset");
                $('#modalInfoPrestataire').modal('hide');
                swal("Ajouté !", data, "success");
              });
          });
            
            $(document).delegate("#enregisterModification","click",function(e){
              $.post("../ProduitDealUpdate",{
                  id:$(".editmodale input[name='id']").val(),
                  libelle:$(".editmodale input[name='libelle']").val(),
                  documentationTechnique:$(".editmodale input[name='documentationTechnique']").val(),
                  image:$(".editmodale input[name='image']").val(),
                  categorie:$(".editmodale select[name='categorie']").val()
              },function(data){
                  //tablef.ajax.reload();
                  swal("Modifié !", data, "success");
                  $.uniform.update();


                    $('#formAjoutProduit').find('input, select').attr('disabled',true);
                    $('#btnAnnuler').hide();
                    $("#enregisterModification").html("Modifier");
                    $("#enregisterModification").attr('id',"modifierArticle");
              });
          });

            $(document).delegate("#selectType","change",function(e){
                
                if(this.value == 'article')
                {
                    //alert( '0' );
                    $(".actionbutton").attr('id',"ajouterArticle");
                    $("#qte").prop('disabled', false);
                    $("#prix").prop('disabled', false);

                    
                }
                if(this.value == 'booking')
                {
                    //alert('1' );
                    $(".actionbutton").attr('id',"ajouterBooking");
                    $("#qte").prop('disabled', true);
                    $("#prix").prop('disabled', false);
                } 
                if(this.value == 'deal')
                {
                    //alert('2');
                    $(".actionbutton").attr('id',"ajouterDeal");
                    $("#qte").prop('disabled', true);
                    $("#prix").prop('disabled', true);
                } 
                if(this.value == 'prestation')
                {
                    //alert( '3' );
                    $(".actionbutton").attr('id',"ajouterPrestation");
                    $("#qte").prop('disabled', true);
                    $("#prix").prop('disabled', false);
                }                
          });


          $(document).delegate("#ajouterArticle","click",function(e){
              $.post("./AjouterArticle",{
                        libelle:$("input[name='libelle']").val(),
                        categorie_id:$("select[name='categorie']").val(),
                        documentation:$("input[name='documentation']").val(),
                        documentationTechnique:$("input[name='documentationTechnique']").val(),
                        image:$("input[name='image']").val(),
                        prix:$("input[name='prix']").val(),
                        qte:$("input[name='qte']").val()
                    },function(data, status){
                        //swal("Ajouté !", data, "success");
                        window.location.replace("ProduitsByID/"+data);
                        $(this).closest('form').find("input[type=text], textarea").val("");
                    });
          });

          $(document).delegate("#ajouterBooking","click",function(e){
              $.post("./AjouterBooking",{
                        libelle:$("input[name='libelle']").val(),
                        categorie_id:$("select[name='categorie']").val(),
                        documentation:$("input[name='documentation']").val(),
                        documentationTechnique:$("input[name='documentationTechnique']").val(),
                        image:$("input[name='image']").val(),
                        prix:$("input[name='prix']").val()
                    },function(data, status){
                        //swal("Ajouté !", data, "success");
                        window.location.replace("ProduitsByID/"+data);
                        $("#formAjoutProduit").trigger("reset");
                    });
          });

          $(document).delegate("#ajouterDeal","click",function(e){
              $.post("./AjouterDeal",{
                        libelle:$("input[name='libelle']").val(),
                        categorie_id:$("select[name='categorie']").val(),
                        documentation:$("input[name='documentation']").val(),
                        documentationTechnique:$("input[name='documentationTechnique']").val(),
                        image:$("input[name='image']").val()
                    },function(data, status){
                        //swal("Ajouté !", data, "success");

                        window.location.replace("ProduitsByID/"+data);
                        $("#formAjoutProduit").trigger("reset");
                    });
          });

          $(document).delegate("#ajouterPrestation","click",function(e){
              $.post("./AjouterPrestation",{
                        libelle:$("input[name='libelle']").val(),
                        categorie_id:$("select[name='categorie']").val(),
                        documentation:$("input[name='documentation']").val(),
                        documentationTechnique:$("input[name='documentationTechnique']").val(),
                        image:$("input[name='image']").val(),
                        prix:$("input[name='prix']").val()
                    },function(data, status){
                        //swal("Ajouté !", data, "success");
                        window.location.replace("ProduitsByID/"+data);
                        $("#formAjoutProduit").trigger("reset");
                    });
          });

      });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.prestataire', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>