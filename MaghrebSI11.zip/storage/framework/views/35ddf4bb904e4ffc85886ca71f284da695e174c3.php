<?php $__env->startSection('title',"Commerciale - Tableau de bord"); ?>

<?php $__env->startSection('js_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.commerciale', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>