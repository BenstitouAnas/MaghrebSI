<?php $__env->startSection('title',"Préstataire - Transactions"); ?>

<?php $__env->startSection('js_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-flat">
    <div class="panel-heading">
        <h6 class="panel-title">Historique des Transactions<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
        <div class="heading-elements">
            <ul class="icons-list">
                <li><a data-action="collapse"></a></li>
            </ul>
        </div>
    </div>

<div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Montant</th>
                <th>Motif</th>
                <th>Date Transaction</th>
            </tr>
        </thead>
        <tbody>
            <?php ($index=1); ?>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index); ?></td>

                <?php if($transaction->evaluation=="+"): ?>
                    <td><span class="text-success-600"><i class="icon-stats-growth2 position-left"></i> <?php echo e($transaction->montant); ?></span></td>
                <?php endif; ?>
                <?php if($transaction->evaluation=="-"): ?>
                    <td><span class="text-danger"><i class="icon-stats-decline2 position-left"></i> <?php echo e($transaction->montant); ?></span></td>
                <?php endif; ?>

                <td><?php echo e($transaction->motif); ?></td>
                <td><?php echo e($transaction->created_at); ?></td>
            </tr>
            <?php ($index++); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_footer'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.prestataire', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>